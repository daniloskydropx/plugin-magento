<?php

/**
 * Copyright � 2015 Inchoo d.o.o.
 * created by Zoran Salamun(zoran.salamun@inchoo.net).
 */

namespace VexShipping\Skydropx\Controller\Process;

class Validate extends \Magento\Framework\App\Action\Action
{
    protected $_context;
    protected $_pageFactory;
    protected $_jsonEncoder;

    protected $_checkoutSession;
    protected $order;
    protected $customerSession;
    private $orderRepository;
    protected $_storeManager;

    protected $_orderAmount;
    protected $soapClientFactory;

    protected $_productRepository;
    protected $_soap;
    protected $_commentFactory;
    protected $_logger;


    public function __construct(
        \Magento\Framework\Webapi\Soap\ClientFactory $soapClientFactory,
        \Magento\Sales\Model\Order $_orderAmount,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Sales\Model\Order\Address $order,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \VexShipping\Skydropx\Model\BrandFactory $brandFactory,
        \Magento\Framework\Json\EncoderInterface $encoder,
        \Psr\Log\LoggerInterface $logger

    ) {
        $this->soapClientFactory = $soapClientFactory;
        $this->_orderAmount = $_orderAmount;
        $this->_storeManager = $storeManager;
        $this->orderRepository = $orderRepository;
        $this->customerSession = $customerSession;
        $this->order = $order;
        $this->scopeConfig = $scopeConfig;
        $this->_checkoutSession = $checkoutSession;
        $this->_context = $context;
        $this->_pageFactory = $pageFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_jsonEncoder = $encoder;
        $this->_commentFactory = $brandFactory;
        $this->_logger = $logger;

        // $this->_productRepository = $productRepository;
        parent::__construct($context);
    }

    public function execute()
    {
        $result = $this->resultJsonFactory->create();

        $dat = ['status' => 'sucess', 'code' => 200];
        // $model = $this->_commentFactory->create();
        // $model->setData('id_order', 101);
        // $model->setData('increment_order', 110);
        // $model->setData('status', 1);
        // $model->setData('skydropx_log_cancel', json_encode($_POST));
        // $model->setData('status_order', 'test');
        // $model->save();

        return $result->setData($dat);
    }
}
