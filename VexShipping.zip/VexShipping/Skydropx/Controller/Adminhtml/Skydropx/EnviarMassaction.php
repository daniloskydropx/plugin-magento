<?php

namespace VexShipping\Skydropx\Controller\Adminhtml\Skydropx;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Backend\App\Action;
use VexShipping\Skydropx\Api\Variables;
use Magento\TestFramework\ErrorLog\Logger;

/**
 * MassBlogDelete Class
 */
class EnviarMassaction extends \Magento\Backend\App\Action
{

    protected $skydropxModel;
    protected $_massModel;
    protected $_helperData;
    protected $helperdata;
    protected $_storeManager;

    public function __construct(
        \VexShipping\Skydropx\Model\BrandFactory $skydropxModel,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \VexShipping\Skydropx\Helper\Data $helperdata,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Ui\Component\MassAction\Filter $massModel,
        Action\Context $context
    ) {
        $this->skydropxModel = $skydropxModel;
        $this->_massModel = $massModel;
        $this->_storeManager = $storeManager;
        $this->_scopeConfig = $scopeConfig;
        $this->helperdata = $helperdata;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {

       

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $direccionadmin = $this->helperdata->getDireccion();
        $telefonoadmin = $this->helperdata->getTelefonoContacto();
        $nombreadmin = $this->helperdata->getNombreContacto();
        $zipadmin = $this->helperdata->getPostCode();
        $referenciaadmin = $this->helperdata->getReferencia();
        $regionadmin = $this->helperdata->getRegion();
        $cityadmin = $this->helperdata->getCity();
        $emailadmin = $this->helperdata->getEmail();


        // datos pendientes
        $telefonoadmin = $this->helperdata->getTelefonoContacto();
        $nombreadmin = $this->helperdata->getNombreContacto();
        $referenciaadmin = $this->helperdata->getReferencia();
        // datos pendientes


        $Collection = $this->skydropxModel->create()->getCollection();
        $model = $this->_massModel;
        $collection = $model->getCollection($Collection);
        $contador = 0;
        try {
            foreach ($collection as $skydropx) {
              
                if (empty($skydropx->getIdSkydropx()) && $skydropx->getStatus() == 1) {
                    $order = $objectManager->create('Magento\Sales\Model\Order')->load($skydropx->getIdOrder());

                    if ($order->getId()) {

                        // orden skydropx
                        $shipping = $order->getShippingMethod();
                        $shipping_coder = explode('_', $shipping);
                        $shipping_data = explode('&', $shipping);
                        $rates = json_decode($shipping_data[1], true);

                        

                        if ($shipping_coder[0] == 'skydropx') {

                            $items = $order->getAllVisibleItems();
                            $weight = 0;
                            $width  = 0;
                            $height = 0;
                            $depth  = 0;
                            foreach ($items as $item) {
                                $producto = $objectManager->create('Magento\Catalog\Model\Product')->load($item->getProduct()->getId());

                                if ($producto->getTypeId() != "configurable") {
                                    $weight += $item->getWeight() * $item->getQtyOrdered();
                                    $width  += floatval($producto->getData("skydropx_width")) * $item->getQtyOrdered();
                                    $height += floatval($producto->getData("skydropx_height")) * $item->getQtyOrdered();
                                    $depth  += floatval($producto->getData("skydropx_long")) * $item->getQtyOrdered();
                                    // $parcels[] = array(
                                    //     "weight" => $productWeight,
                                    //     "distance_unit" => "CM",
                                    //     "mass_unit" => "KG",
                                    //     "height" => floatval($producto->getData("skydropx_height")) * $item->getQtyOrdered(),
                                    //     "width" => floatval($producto->getData("skydropx_width")) * $item->getQtyOrdered(),
                                    //     "length" => floatval($producto->getData("skydropx_long")) * $item->getQtyOrdered(),
                                    // );
                                }
                            }

                            $orderShippingAddress = $order->getShippingAddress();
                            $street = $orderShippingAddress->getData('street');
                            $streetarray = explode("\n", $street);
                            $street = trim($streetarray[0]);

                            $nombrecliente = $orderShippingAddress->getData('firstname') . " " . $orderShippingAddress->getData('lastname');
                            $telefonocliente = $orderShippingAddress->getTelephone();
                            $emailcliente = $orderShippingAddress->getEmail();
                            $zipcliente = $orderShippingAddress->getPostcode();
                            $citycliente = $orderShippingAddress->getCity();
                            $regioncliente = $orderShippingAddress->getRegion();

                            $referenciacliente = "";
                            if (isset($streetarray[1])) {
                                $referenciacliente .= $streetarray[1];
                            }


                            if (isset($streetarray[2])) {
                                $referenciacliente .= ", " . $streetarray[2];
                            }

                            $shop_id = $this->getShopId();
                          
                            if (!$shop_id) {
                                throw new \Magento\Framework\Exception\LocalizedException(
                                    __("Error en crear Shop Skydropx")
                                );
                            }

                            $request = array(
                                "number" => $order->getId(),
                                "shop_id" => $shop_id,
                                "consignment_note_class_code" => '24112900',
                                "consignment_note_packaging_code" => "1H1",
                                "shipment" => array(
                                    "rates" => array(
                                        "provider" => $rates[0],
                                        "service_level_code" => $rates[1]
                                    )
                                ),
                                "address_to" =>  array(
                                    "province" => $regioncliente,
                                    "city" => $citycliente,
                                    "name" => $nombrecliente,
                                    "zip" => $zipcliente,
                                    "country" => 'MX',
                                    "address1" => $street,
                                    "address2" => $referenciacliente,
                                    "phone" => $telefonocliente,
                                    "email" => $emailcliente,

                                ),
                                "parcels" => [
                                    [
                                        "weight" => $weight > 0 ? (int)number_format($weight, 0, '.', '') : 1,
                                        "distance_unit" => "CM",
                                        "mass_unit" => "KG",
                                        "height" => $height > 0 ? $height : 1,
                                        "width" => $width > 0 ? $width : 1,
                                        "length" => $depth > 0 ? $depth : 1
                                    ]
                                ],
                                "address_from" =>  array(
                                    "province" => $regionadmin,
                                    "city" => $cityadmin,
                                    "name" => $nombreadmin,
                                    "zip" => $zipadmin,
                                    "country" => 'MX',
                                    "address1" => $direccionadmin,
                                    "address2" => $referenciaadmin,
                                    "phone" => $telefonoadmin,
                                    "email" => $emailadmin,
                                    "reference" => '-',
                                    "contents" => 'Mercancia',
                                )
                            );


                            // throw new \Magento\Framework\Exception\LocalizedException(
                            //     __("Prueba " . json_encode($request))
                            // );

                            $response = $this->postOrderSkydropx($request);
                            $skydropx->setData('skydropx_log_cancel', json_decode($response));
                            if ($response == 'OK') {
                                // $model->setData('id_skydropx', 1)->setData("fecha", date("Y-m-d H:i:s"))->save();
                                $skydropx->setData('id_skydropx', 1)->setData('status', 2)->setData("fecha", date("Y-m-d H:i:s"))->save();
                                $contador = $contador + 1;
                            } else {
                                throw new \Magento\Framework\Exception\LocalizedException(
                                    __("There was a problem in sending the order to Skydropx.")
                                );
                            }

                            // if (isset($response->id)) {
                            //     $skydropx->setData('status', 2)->setData('id_skydropx', $response->id)->setData("fecha", date("Y-m-d H:i:s"))->save();
                            //     if ($estadoordencambio) {
                            //         $order->setStatus($estadoordennuevo);
                            //     }
                            //     $order->setIdskydropx($response->id)->save();
                            //     $contador = $contador + 1;
                            // } else {
                            //     throw new \Magento\Framework\Exception\LocalizedException(
                            //         __("There was a problem in sending the order to Skydropx.")
                            //     );
                            // }
                        }
                    }
                }
            }
            $this->messageManager->addSuccess(__('%1 orders were shipped', $contador));
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('vexshipping_skydropx/skydropx/index');
    }

    /**
     * Check for is allowed
     *
     * @return boolean
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('VexShipping_Skydropx::skydropx');
    }

    private function postOrderSkydropx($request)
    {
        $curl = curl_init();
        $debug = Variables::MODE_PRODUCTION;
        $url = $debug == 1 ? Variables::URL_TEST_ORDER : Variables::URL_PRODUCTION_ORDER;
        $key = $this->helperdata->getApiKey();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($request),
            CURLOPT_HTTPHEADER => array(
                'Authorization: token=' . $key,
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }


    private function getShopId()
    {
        $debug = Variables::MODE_PRODUCTION;
        $model_shop = $this->skydropxModel->createShop()->load($debug, 'type');
        $key = $this->helperdata->getApiKey();

        if (!$model_shop->getType()) {
            $model_shop = $this->skydropxModel->createShop();
            $url = $debug == 1 ? Variables::URL_TEST_SHOP : Variables::URL_PRODUCTION_SHOP;
            $curl = curl_init();

            $data = array(
                "shop_reference" => '000' . $debug,
                "name" => "magento",
                "country" => "MX",
                "webhook" => $this->_storeManager->getStore()->getBaseUrl() . "rest/V1/postWebHook",
                "provider" => "magento",
                "headquarter_uuid" => "123123",

            );

            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => array(
                    'Authorization: token=' . $key,
                    'Content-Type: application/json'
                ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);

            $response = json_decode($response);

            if ($response->success) {
                $model_shop->setData('type', $debug)->setData('id_shop', $response->data->_id)->setData('web_hook', $response->data->webhook)->save();
                return $model_shop->getIdShop();
            }

            return false;
        }

        return $model_shop->getIdShop();
    }
}
