<?php
namespace VexShipping\Skydropx\Helper;

class Data
{

    protected $scopeConfig;
    
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    )
    {
        $this->scopeConfig = $scopeConfig;
    }


    public function getDataconfig($name){
        return $this->scopeConfig->getValue('carriers/skydropx/'.$name, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    
    public function getActive(){
        return $this->getDataconfig("active");
    }
    public function getNombre(){
        return $this->getDataconfig("name");
    }
    public function getTitulo(){
        return $this->getDataconfig("titulo");
    }

    public function getTipoPrecio(){
        return $this->getDataconfig("tipo_precio");
    }

    public function getPrecio(){
        return $this->getDataconfig("precio");
    }

    public function getEstadoPedido(){
        return $this->getDataconfig("skydropx_w5/estado_pedido");
    }
   

    public function getNombreContacto(){
        return $this->getDataconfig("skydropx_w1/nombre_contacto");
    }

    public function getPostCode(){
        return $this->getDataconfig("skydropx_w1/postcode");
    }

    public function getCity(){
        return $this->getDataconfig("skydropx_w1/city");
    }

    public function getRegion(){
        return $this->getDataconfig("skydropx_w1/region");
    }

    public function getEmail(){
        return $this->getDataconfig("skydropx_w1/nombre_email");
    }


    public function getTelefonoContacto(){
        return $this->getDataconfig("skydropx_w1/nombre_telefono");
    }
    public function getDireccion(){
        return $this->getDataconfig("skydropx_w1/direccion");
    }
    public function getReferencia(){
        return $this->getDataconfig("skydropx_w1/referencia");
    }
  
    public function getFeriados(){
        return $this->getDataconfig("skydropx_w1/commands_list");
    }
    public function getTrabajos(){
        return $this->getDataconfig("skydropx_w1/commands_list_work");
    }

    public function getApiKey(){
        return $this->getDataconfig("apikeySkydropx");
    }
  
    public function getHorario(){
        return $this->getDataconfig("skydropx_w4/horario");
    }

}