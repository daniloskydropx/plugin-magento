<?php

namespace VexShipping\Skydropx\Block\Adminhtml\Order;

use Magento\Sales\Model\Order;  

class Detalle extends \Magento\Backend\Block\Template
{
 
    protected $coreRegistry = null;
    private $scopeConfig;
    protected $helperdata;
    //protected $_template = 'order/view/facturacion_fields.phtml';
  
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \VexShipping\Skydropx\Helper\Data $helperdata,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->coreRegistry = $registry;
        $this->scopeConfig = $scopeConfig;
        $this->helperdata = $helperdata;
        $this->_isScopePrivate = true;  
        parent::__construct($context, $data);
    }


    public function getOrderId() 
    {
        
        $order = $this->coreRegistry->registry('current_order');
        
        $order_id = '';

        if(!$order){
 
        }
        else
        {
            $order_id = $order->getId();
        } 
        
        return $order_id;
    } 
 
    public function getQuoteId() 
    {
        
        $order = $this->coreRegistry->registry('current_order');
        
        $quote_id = '';

        if(!$order){
 
        }
        else
        {
            $quote_id = $order->getQuoteId();
        } 
        
        return $quote_id;
    } 

    public function getShippingDate(){

        $order = $this->coreRegistry->registry('current_order');
        
        if($order){

                return [
                    "fecha" => $order->getShippingAddress()->getData("fechaenvio"),
                    "id" => $order->getIdskydropx(),
                    'metodo' => $order->getShippingMethod()
                    ];
            


        }    

        return false;
    }

    public function getDataskydropx($skydropx){
        return false;
    }

    public function key(){
        $key = $this->scopeConfig->getValue('vexsolucionescheckout/general/key', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $key;
    }
      
}
