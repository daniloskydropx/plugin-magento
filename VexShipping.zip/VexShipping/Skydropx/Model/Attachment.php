<?php

namespace VexShipping\Skydropx\Model;

use VexShipping\Skydropx\Api\AttachmentInterface;
use Magento\Framework\View\Asset\Repository;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Attachment extends Command implements AttachmentInterface
{

    public $labelURL;


    protected function configure()
    {
        $this->setName('samplemodule:logger');
        $this->setDescription('Barbanet_SampleModule Logger test command');
    }

    public function setLabelURL($labelURL)
    {
        $this->$labelURL = $labelURL;
        
    }

    public function getLabelURL()
    {
        return $this->labelURL;
    }

}