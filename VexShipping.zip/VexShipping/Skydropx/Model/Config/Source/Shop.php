<?php

namespace VexShipping\Skydropx\Model\Config\Source;
use VexShipping\Skydropx\Api\Variables;

class Shop implements \Magento\Framework\Option\ArrayInterface
{
    protected $skydropxModel;

    public function __construct(
        \VexShipping\Skydropx\Model\BrandFactory $skydropxModel
    ) {
        $this->skydropxModel = $skydropxModel;
    }

    public function toOptionArray()
    {
        return [
            ['value' => 0 , 'label' => __($this->getShopId())],
        ];
    }

    private function getShopId()
    {
        $debug = Variables::MODE_PRODUCTION;
        $model_shop = $this->skydropxModel->createShop()->load($debug, 'type');
        return $model_shop->getIdShop();
    }
}
