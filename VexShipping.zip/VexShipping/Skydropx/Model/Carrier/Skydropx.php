<?php

namespace VexShipping\Skydropx\Model\Carrier;

use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Shipping\Model\Carrier\AbstractCarrier;
use Magento\Shipping\Model\Carrier\CarrierInterface;
use Magento\Framework\App\ObjectManager;
use VexShipping\Skydropx\Api\Variables;

class Skydropx extends AbstractCarrier implements CarrierInterface
{
    const CODE = 'skydropx';
    private $scopeConfig;

    protected $_code = self::CODE;
    protected $_session;
    protected $checkoutSession;
    protected $request;
    protected $addressRepository;
    protected $objectManager;

    private $_rateResultFactory;
    private $_rateMethodFactory;
    private $trackStatusFactory;
    private $_addressFactory;

    public $_postcode = "";
    public $totalkilos = 0;
    public $totalancho = 0;
    public $totallargo = 0;
    public $totalalto = 0;
    public $totalproductos = 0;


    public $anchopaquete = 40;
    public $largopaquete = 30;
    public $altopaquete = 40;
    public $pesopaquete = 9;
    public $numeroarticulos = 10;
    protected $_logger;
    protected $_storeManager;

    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory,
        \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory,
        \Magento\Checkout\Model\Session $session,
        \Magento\Framework\Webapi\Rest\Request $request,
        CheckoutSession $checkoutSession,
        \Magento\Customer\Model\AddressFactory $addressFactory,
        \Magento\Customer\Api\AddressRepositoryInterface $addressRepository,
        \Magento\Shipping\Model\Tracking\Result\StatusFactory $trackStatusFactory,
        array $data = []
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->_rateResultFactory = $rateResultFactory;
        $this->_rateMethodFactory = $rateMethodFactory;
        $this->_storeManager = $storeManager;
        $this->request = $request;
        $this->_session = $session;
        $this->addressRepository = $addressRepository;
        $this->checkoutSession = $checkoutSession;
        $this->trackStatusFactory = $trackStatusFactory;
        $this->_addressFactory = $addressFactory;
        $this->_logger = $logger;
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }

    /**
     * get allowed methods.
     *
     * @return array
     */
    public function getAllowedMethods()
    {
        return [
            $this->_code => $this->getConfigData('name'),
        ];
    }



    public function collectRates(RateRequest $request)
    {
        $this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $items = $request->getAllItems();
        foreach ($items as $item) {
            $producto = $this->objectManager->create('Magento\Catalog\Model\Product')->load($item->getProduct()->getId());
            if ($producto->getTypeId() != "configurable") {
                $productWeight = $item->getWeight() * $item->getQty();
                $this->totalkilos = $this->totalkilos + $productWeight;

                $totalanchoaux = floatval($producto->getData("skydropx_width")) * $item->getQty();
                $totalaltoaux = floatval($producto->getData("skydropx_height")) * $item->getQty();
                $totallargoaux = floatval($producto->getData("skydropx_long")) * $item->getQty();

                $this->totalancho = $this->totalancho + $totalanchoaux;
                $this->totallargo = $this->totallargo + $totallargoaux;
                $this->totalalto = $this->totalalto + $totalaltoaux;
                $this->totalproductos = $this->totalproductos + $item->getQty();
            }
        }
        $result = $this->_rateResultFactory->create();
        $this->_postcode = $request->getDestPostcode();
        if ($this->_postcode == null || $this->_postcode == '') {
            $error = $this->_rateErrorFactory->create(
                [
                    'data' => [
                        'carrier' => $this->_code,
                        'carrier_title' => $this->getConfigData('titulo'),
                        'error_message' => "Pendiente codigo postal",
                    ],
                ]
            );
            $result->append($error);
            return $result;
        }

        $routes = $this->getRoutSkydrox();
        // $this->_logger->debug("data routes : " . json_encode($routes));


        if ($routes) {
            $this->_logger->debug("data test : " . json_encode($routes));
            foreach ($routes as $key => $route) {
                $name = $this->_code . "_" . $key . "&" . json_encode([$route['provider'], $route['service_level_code']]);

                $method = $this->_rateMethodFactory->create();
                $method->setCarrier($this->_code);
                $method->setCarrierTitle($this->getConfigData('title'));
                $method->setMethod($name);

                // $method->setMethod($code);
                $method->setMethodTitle($route['provider'] . " - " .  $route['service_level_name'] . " - ". $route['days'] . " dias");

                $amount = $route['total_pricing'];

                $method->setPrice($amount);

                $result->append($method);
            }
        }

        return $result;
    }

    private function isSerialized($value)
    {
        return (bool) preg_match('/^((s|i|d|b|a|O|C):|N;)/', $value);
    }

    private function getRoutSkydrox()
    {
        $debug = Variables::MODE_PRODUCTION;
        $url = $debug == 1 ? Variables::URL_TEST : Variables::URL_PRODUCTION;
        $key = $this->getConfigData('apikeySkydropx');
        $wharehouse_zip = $this->getConfigData('skydropx_w1/postcode');
        $data = array(
            "zip_from" => $wharehouse_zip,
            "zip_to" => $this->_postcode,
            "parcel" => array(
                "weight" => $this->totalkilos > 0 ? $this->totalkilos : 1,
                "height" => $this->totalalto > 0 ? $this->totalalto : 1,
                "width" => $this->totalancho > 0 ? $this->totalancho : 1,
                "length" => $this->totallargo > 0 ? $this->totallargo : 1,
            )
        );
        // $this->_logger->debug("request skydroxp: " . json_encode($data));
        // $this->_logger->debug("URL skydroxp: " . $url . 'rates');
        $cliente = $this->objectManager->get('\Magento\Framework\HTTP\ZendClientFactory');

        $client = $cliente->create();
        $client->setUri($url . 'rates');
        $client->setMethod(\Zend_Http_Client::POST);
        $client->setHeaders(\Zend_Http_Client::CONTENT_TYPE, 'application/json');
        $client->setHeaders('Accept', 'application/json');
        $client->setHeaders("Authorization", "Token token=" . $key);
        $client->setRawData(json_encode($data));
        $response = $client->request();

        $this->_logger->debug("data skydroxp: " . $response->getBody());
        $response = json_decode($response->getBody(), true);

        if (isset($response['data'])) {
            return $response['data'];
        }

        return false;
    }
}
