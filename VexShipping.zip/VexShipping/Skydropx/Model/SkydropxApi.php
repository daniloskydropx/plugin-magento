<?php

namespace VexShipping\Skydropx\Model;

use VexShipping\Skydropx\Api\ComercioInterface;
use Magento\Framework\View\Asset\Repository;
use Symfony\Component\Console\Command\Command;
use VexShipping\Skydropx\Api\AttachmentInterface;
use VexShipping\Skydropx\Api\Variables;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class SkydropxApi extends Command implements ComercioInterface
{

    protected $addressRepository;
    protected $helperdata;
    private $scopeConfig;
    private $assetRepo;
    protected $cart;
    private $logger;

    public $totalkilos = 0;
    public $totalancho = 0;
    public $totallargo = 0;
    public $totalalto = 0;
    public $totalproductos = 0;

    public function __construct(
        // Repository $assetRepo,
        // \Magento\Customer\Api\AddressRepositoryInterface $addressRepository,
        \VexShipping\Skydropx\Helper\Data $helperdata,
        \Magento\Checkout\Model\Cart $cart,
        // \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \VexShipping\Skydropx\Model\BrandFactory $brandFactory
    ) {
        // $this->scopeConfig = $scopeConfig;
        // $this->addressRepository = $addressRepository;
        // $this->assetRepo = $assetRepo;
        $this->helperdata = $helperdata;
        $this->cart = $cart;
        $this->logger = $logger;
        $this->_commentFactory = $brandFactory;
        $this->resultJsonFactory = $resultJsonFactory;
    }

    protected function configure()
    {
        $this->setName('samplemodule:logger');
        $this->setDescription('Barbanet_SampleModule Logger test command');
    }

    public function gettracking($customerId)
    {
    }


    public function verificarPosicion()
    {
    }

    public function processWebHook($orderId, $status = '', $attachment = null)
    {
        $model = $this->_commentFactory->create()->load($orderId, 'id_order');
        // $model->setData('skydropx_log_cancel', $attachment);

        if ($status == 'fulfillment') {
                // $model = $this->_commentFactory->create();
                $model->setData('status', 2);
                $model->setData('status_order', $status);
                $model->setData('skydropx_log', $attachment['label_url']);
                $model->setData('url_provider', $attachment['tracking_url_provider']);
                $model->setData('tracking_number', $attachment['tracking_number']);
                $model->save();
                return true;
        } else if ($status == 'error') {
                $model->setData('status', 0);
                $model->setData('status_order', $status);
                $model->setData('skydropx_log_cancel', $attachment['errors']['consignment_note_class_code'][0]);
                $model->save();
                return false;
        } else {
            $model->setData('status', 0);
            $model->setData('status_order', $status);
            $model->save();
            return false;
        }
        die;
    }

    public function getdataskydropx()
    {
        $this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $request = $this->objectManager->get('Magento\Framework\App\Request\Http');
        $postcode = $request->getParam('postcode');
        $listaitems = $this->cart->getQuote()->getAllItems();

        foreach ($listaitems as $item) {
            $producto = $this->objectManager->create('Magento\Catalog\Model\Product')->load($item->getProduct()->getId());
            if ($producto->getTypeId() != "configurable") {
                $productWeight = $item->getWeight() * $item->getQty();
                $this->totalkilos = $this->totalkilos + $productWeight;

                $totalanchoaux = floatval($producto->getData("skydropx_width")) * $item->getQty();
                $totalaltoaux = floatval($producto->getData("skydropx_height")) * $item->getQty();
                $totallargoaux = floatval($producto->getData("skydropx_long")) * $item->getQty();

                $this->totalancho = $this->totalancho + $totalanchoaux;
                $this->totallargo = $this->totallargo + $totallargoaux;
                $this->totalalto = $this->totalalto + $totalaltoaux;
                $this->totalproductos = $this->totalproductos + $item->getQty();
            }
        }

        $routes = $this->getRoutSkydrox($postcode);
        if (is_array($routes)) {
            return array(array(
                "status" => true,
                "body" => $routes
            ));
        }else{
            return array(array(
                "status" => false
            ));
        }
    }

    private function getRoutSkydrox($_postcode)
    {
        $debug = Variables::MODE_PRODUCTION;
        $url = $debug == 1 ? Variables::URL_TEST : Variables::URL_PRODUCTION;
        $key = $this->helperdata->getApiKey();
        $wharehouse_zip = $this->helperdata->getPostCode();

        $data = array(
            "zip_from" => $wharehouse_zip,
            "zip_to" => $_postcode,
            "parcel" => array(
                "weight" => $this->totalkilos > 0 ? $this->totalkilos : 1,
                "height" => $this->totalalto > 0 ? $this->totalalto : 1,
                "width" => $this->totalancho > 0 ? $this->totalancho : 1,
                "length" => $this->totallargo > 0 ? $this->totallargo : 1,
            )
        );
        $cliente = $this->objectManager->get('\Magento\Framework\HTTP\ZendClientFactory');

        $client = $cliente->create();
        $client->setUri($url . 'rates');
        $client->setMethod(\Zend_Http_Client::POST);
        $client->setHeaders(\Zend_Http_Client::CONTENT_TYPE, 'application/json');
        $client->setHeaders('Accept', 'application/json');
        $client->setHeaders("Authorization", "Token token=" . $key);
        $client->setRawData(json_encode($data));
        $response = $client->request();

        $this->logger->debug("data skydroxp: " . $response->getBody());
        $response = json_decode($response->getBody(), true);

        if (isset($response['data'])) {
            return $response;
        }

        return false;
    }



    private function isSerialized($value)
    {
        return (bool) preg_match('/^((s|i|d|b|a|O|C):|N;)/', $value);
    }


    public function getDataTrakingSkydropx()
    {
    }
}
