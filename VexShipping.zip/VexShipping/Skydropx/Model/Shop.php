<?php
/**
 * Copyright © 2015 VexShipping. All rights reserved.
 */

namespace VexShipping\Skydropx\Model;

class Shop extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init('VexShipping\Skydropx\Model\ResourceModel\Shop');
    }
}
