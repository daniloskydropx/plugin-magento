<?php

namespace VexShipping\Skydropx\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{

    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {

        $setup->startSetup();

        $table  = $setup->getConnection()
            ->newTable($setup->getTable('vexsoluciones_skydropx'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )
            ->addColumn(
                'id_skydropx',
                Table::TYPE_INTEGER,
                null,
                ['default' => null],
                'id_skydropx'
            )
            ->addColumn(
                'id_order',
                Table::TYPE_INTEGER,
                null,
                ['default' => null],
                'id_order'
            )
            ->addColumn(
                'increment_order',
                Table::TYPE_TEXT,
                null,
                ['default' => null],
                'increment_order'
            )
            ->addColumn(
                'status_order',
                Table::TYPE_TEXT,
                null,
                ['default' => null],
                'status_order'
            )
            ->addColumn(
                'tracking_number',
                Table::TYPE_TEXT,
                null,
                ['default' => null],
                'status_order'
            )
            ->addColumn(
                'url_provider',
                Table::TYPE_TEXT,
                null,
                ['default' => null],
                'status_order'
            )
            ->addColumn(
                'skydropx_log',
                Table::TYPE_TEXT,
                null,
                ['default' => null],
                'skydropx_log'
            )
            ->addColumn(
                'status',
                Table::TYPE_INTEGER,
                null,
                ['default' => null],
                'status'
            )->addColumn(
                'fecha',
                Table::TYPE_TIMESTAMP,
                null,
                ['default' => null],
                'fecha'
            )->addColumn(
                'skydropx_log_cancel',
                Table::TYPE_TEXT,
                true,
                ['default' => null],
                'skydropx_log_cancel'
            );

        $setup->getConnection()->createTable($table);

        $table_shop_skydrox  = $setup->getConnection()
            ->newTable($setup->getTable('vexsoluciones_skydropx_shops'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )
            ->addColumn(
                'type',
                Table::TYPE_INTEGER,
                null,
                ['default' => null],
                'type'
            )
            ->addColumn(
                'id_shop',
                Table::TYPE_TEXT,
                null,
                ['default' => null],
                'id_shop'
            )
            ->addColumn(
                'web_hook',
                Table::TYPE_TEXT,
                null,
                ['default' => null],
                'increment_order'
            );

        $setup->getConnection()->createTable($table_shop_skydrox);

        $setup->endSetup();
    }
}
