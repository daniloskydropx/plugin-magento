<?php
 
namespace VexShipping\Skydropx\Logger\Handler;
 
use Magento\Framework\Logger\Handler\Base;
use Monolog\Logger;

class Log extends Base
{

    /**
     * @var string
     */
    protected $fileName = '/var/log/skydropx_log.log';
  /**
     * @var
     */
    protected $loggerType = Logger::DEBUG;
}