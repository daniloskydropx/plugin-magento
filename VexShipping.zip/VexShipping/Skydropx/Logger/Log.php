<?php
 
namespace VexShipping\Skydropx\Logger; 
use Monolog\Logger;

class Log extends Logger 
{

}