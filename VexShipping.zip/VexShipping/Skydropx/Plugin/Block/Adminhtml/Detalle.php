<?PHP

namespace VexShipping\Skydropx\Plugin\Block\Adminhtml;

use Magento\Framework\Exception\LocalizedException;     


class Detalle
{
  
    public function afterToHtml(\Magento\Sales\Block\Adminhtml\Order\View\Info $subject, $result) {
 
        
        $order = $subject->getOrder();
         
        $blockShippingDate = $subject->getLayout()->createBlock(
            'VexShipping\Skydropx\Block\Adminhtml\Order\Detalle'
        );
 
        $blockShippingDate->setTemplate('VexShipping_Skydropx::order/Detalle.phtml'); // FeFacturacionFieldsView
    
        if ($blockShippingDate !== false) {
  
            $result = $result.$blockShippingDate->toHtml();
        }
 
        return $result;
    }
}