<?php
namespace VexShipping\Skydropx\Api;
interface ComercioInterface 
{
    /**
     * Get customer questions
     *
     * @api
     * @param int $customerId
     * @return string questions
     */
    public function gettracking($customerId);
    /**
     * Get customer questions
     *
     * @api
     * @return string questions
     */
    public function getdataskydropx();

     /**
     * Get customer questions
     *
     * @api
     * @return string questions
     */
    public function verificarPosicion();

    /**
     * Get customer questions
     *
     * @api
     * @return string questions
     */
    public function getDataTrakingSkydropx();


/**
     * Resend confirmation email.
     *
     * @param int $orderId
     * @param string $status
     * @param mixed $attachment
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function processWebHook($orderId, $status = '', $attachment = null);

}