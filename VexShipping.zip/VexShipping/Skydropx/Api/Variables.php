<?PHP 

namespace VexShipping\Skydropx\Api; 

interface Variables{
   
   const URL_TEST = 'https://sb-ecommerce-service.skydropx.com/v1/';
   const URL_PRODUCTION = 'https://ecommerce-service.skydropx.com/v1/';

   const URL_TEST_ORDER = 'https://sb-ecommerce-service.skydropx.com/v1/order/';
   const URL_PRODUCTION_ORDER = 'https://ecommerce-service.skydropx.com/v1/order/';

   const URL_TEST_SHOP = 'https://sb-ecommerce-service.skydropx.com/v1/shop';
   const URL_PRODUCTION_SHOP = 'https://ecommerce-service.skydropx.com/v1/shop';
   

   /**
    * 1 = modo pruebas
    * 2 = modo produccion
    */
   const MODE_PRODUCTION = 2;
   
   // api de pruebas
}