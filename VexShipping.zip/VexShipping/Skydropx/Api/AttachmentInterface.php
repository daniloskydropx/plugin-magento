<?php

namespace VexShipping\Skydropx\Api;

interface AttachmentInterface
{
    /**
     * Set labelURL webhook
     *
     * @param string $labelURL
     * @return $this
     */
    public function setLabelURL($labelURL);

     /**
     * Get labelURL webhook
     *
     * @return string
     */
    public function getLabelURL();
}
