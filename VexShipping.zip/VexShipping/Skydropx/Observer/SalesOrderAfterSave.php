<?php

namespace VexShipping\Skydropx\Observer;

use Magento\Framework\Event\ObserverInterface;
use VexShipping\Skydropx\Api\Variables;

class SalesOrderAfterSave implements ObserverInterface
{

    protected $scopeConfig;
    protected $addressRepository;
    protected $helperdata;
    protected $_commentFactory;
    protected $_storeManager;

    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \VexShipping\Skydropx\Helper\Data $helperdata,
        \VexShipping\Skydropx\Model\BrandFactory $brandFactory,
        \Magento\Customer\Api\AddressRepositoryInterface $addressRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->addressRepository = $addressRepository;
        $this->helperdata = $helperdata;
        $this->_commentFactory = $brandFactory;
        $this->_storeManager = $storeManager;
    }


    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $shipping = $order->getShippingMethod();
        $shipping_coder = explode('_', $shipping);



        if (count($shipping_coder) > 0) {
            if ($shipping_coder[0] == 'skydropx') {

                $shop_id = $this->getShopId();

                // throw new \Magento\Framework\Exception\LocalizedException(
                //     __("Ocurrio un error al intentar crear la tienda en Skydrox "  . $shop_id)
                // );

                if (!$shop_id) {
                    throw new \Magento\Framework\Exception\LocalizedException(
                        __("Ocurrio un error al intentar crear la tienda en Skydrox")
                    );
                }

                $shipping_data = explode('&', $shipping);
                $rates = json_decode($shipping_data[1], true);

                $items = $order->getAllVisibleItems();
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

                $parcels = array();
                $weight = 0;
                $width  = 0;
                $height = 0;
                $depth  = 0;

                foreach ($items as $item) {
                    $producto = $objectManager->create('Magento\Catalog\Model\Product')->load($item->getProduct()->getId());

                    if ($producto->getTypeId() != "configurable") {
                        $weight += $item->getWeight() * $item->getQtyOrdered();
                        $width  += floatval($producto->getData("skydropx_width")) * $item->getQtyOrdered();
                        $height += floatval($producto->getData("skydropx_height")) * $item->getQtyOrdered();
                        $depth  += floatval($producto->getData("skydropx_long")) * $item->getQtyOrdered();
                        // $parcels[] = array(
                        //     "weight" => $productWeight,
                        //     "distance_unit" => "CM",
                        //     "mass_unit" => "KG",
                        //     "height" => floatval($producto->getData("skydropx_height")) * $item->getQtyOrdered(),
                        //     "width" => floatval($producto->getData("skydropx_width")) * $item->getQtyOrdered(),
                        //     "length" => floatval($producto->getData("skydropx_long")) * $item->getQtyOrdered(),
                        // );
                    }
                }

                $direccionadmin = $this->helperdata->getDireccion();
                $estadoorden = $this->helperdata->getEstadoPedido();

                $telefonoadmin = $this->helperdata->getTelefonoContacto();
                $nombreadmin = $this->helperdata->getNombreContacto();
                $zipadmin = $this->helperdata->getPostCode();
                $referenciaadmin = $this->helperdata->getReferencia();
                $regionadmin = $this->helperdata->getRegion();
                $cityadmin = $this->helperdata->getCity();
                $emailadmin = $this->helperdata->getEmail();

                $OrderStatus = $order->getStatus();

                $orderShippingAddress = $order->getShippingAddress();
                $street = $orderShippingAddress->getData('street');
                $streetarray = explode("\n", $street);
                $street = trim($streetarray[0]);

                $nombrecliente = $orderShippingAddress->getData('firstname') . " " . $orderShippingAddress->getData('lastname');
                $telefonocliente = $orderShippingAddress->getTelephone();
                $emailcliente = $orderShippingAddress->getEmail();
                $zipcliente = $orderShippingAddress->getPostcode();
                $citycliente = $orderShippingAddress->getCity();
                $regioncliente = $orderShippingAddress->getRegion();

                $referenciacliente = "";
                if (isset($streetarray[1])) {
                    $referenciacliente .= $streetarray[1];
                }
                if (isset($streetarray[2])) {
                    $referenciacliente .= ", " . $streetarray[2];
                }

                $model = $this->_commentFactory->create()->load($order->getId(), 'id_order');
                if (!$model->getId()) {
                    $model = $this->_commentFactory->create();
                    $model->setData('id_order', $order->getId());
                    $model->setData('increment_order', $order->getIncrementId());
                    $model->setData('status', 1);
                    $model->setData('status_order', $OrderStatus);
                } else {
                    $model->setData('status_order', $OrderStatus);
                }
                $model->save();

                if ($order->getIdskydropx() !== null && $order->getIdskydropx() !== 0 && $order->getIdskydropx() !== '') {
                    return false;
                }

                if ($OrderStatus != $estadoorden) {
                    return false;
                }

                $request = array(
                    "number" => $order->getId(),
                    "shop_id" => $shop_id,
                    "consignment_note_class_code" => '24112900',
                    "consignment_note_packaging_code" => "1H1",
                    "shipment" => array(
                        "rates" => array(
                            "provider" => $rates[0],
                            "service_level_code" => $rates[1]
                        )
                    ),
                    "address_to" =>  array(
                        "province" => $regioncliente,
                        "city" => $citycliente,
                        "name" => $nombrecliente,
                        "zip" => $zipcliente,
                        "country" => 'MX',
                        "address1" => $street,
                        "address2" => $referenciacliente,
                        "phone" => $telefonocliente,
                        "email" => $emailcliente,

                    ),
                    "parcels" => [
                        [
                            "weight" => $weight > 0 ? (int)number_format($weight, 0, '.', '') : 1,
                            "distance_unit" => "CM",
                            "mass_unit" => "KG",
                            "height" => $height > 0 ? $height : 1,
                            "width" => $width > 0 ? $width : 1,
                            "length" => $depth > 0 ? $depth : 1
                        ]
                    ],
                    "address_from" =>  array(
                        "province" => $regionadmin,
                        "city" => $cityadmin,
                        "name" => $nombreadmin,
                        "zip" => $zipadmin,
                        "country" => 'MX',
                        "address1" => $direccionadmin,
                        "address2" => $referenciaadmin,
                        "phone" => $telefonoadmin,
                        "email" => $emailadmin,
                        "reference" => '-',
                        "contents" => 'Mercancia',
                    )
                );

                $response = $this->postOrderSkydropx($request);

                // $model->setData('skydropx_log', $responseaux)->save();

                if ($response == 'OK') {
                    $model->setData('status', 2)->setData('id_skydropx', 1)->setData("fecha", date("Y-m-d H:i:s"))->save();
                    $order->setIdskydropx(1)->save();
                } else {
                    throw new \Magento\Framework\Exception\LocalizedException(
                        __("There was a problem in sending the order to Skydropx.")
                    );
                }
            }
        }

        return $this;
    }

    private function getShopId()
    {
        $debug = Variables::MODE_PRODUCTION;
        $model_shop = $this->_commentFactory->createShop()->load($debug, 'type');
        $key = $this->helperdata->getApiKey();

        if (!$model_shop->getType()) {
            $model_shop = $this->_commentFactory->createShop();
            $model_shop->setData('type', $debug)->setData('id_shop', '1234568')->setData('web_hook', "pruebassss")->save();

            $url = $debug == 1 ? Variables::URL_TEST_SHOP : Variables::URL_PRODUCTION_SHOP;
            $curl = curl_init();

            $data = array(
                "shop_reference" => '000' . $debug,
                "name" => "magento",
                "country" => "MX",
                "webhook" => $this->_storeManager->getStore()->getBaseUrl() . "rest/V1/postWebHook",
                "provider" => "magento",
                "headquarter_uuid" => "123123",

            );

            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => array(
                    'Authorization: token=' . $key,
                    'Content-Type: application/json'
                ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);

            $response = json_decode($response);

            if ($response->success) {
                $model_shop->setData('type', $debug)->setData('id_shop', $response->data->_id)->setData('webhook', $response->data->webhook)->save();
                return $model_shop->getIdShop();
            }

            return false;
        }

        return $model_shop->getIdShop();
    }


    private function postOrderSkydropx($request)
    {
        $curl = curl_init();
        $debug = Variables::MODE_PRODUCTION;
        $url = $debug == 1 ? Variables::URL_TEST_ORDER : Variables::URL_PRODUCTION_ORDER;
        $key = $this->helperdata->getApiKey();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($request),
            CURLOPT_HTTPHEADER => array(
                'Authorization: token=' . $key,
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }
}
