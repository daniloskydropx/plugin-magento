<?php

namespace VexShipping\Skydropx\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;


class AddExtraFieldsToOrder implements ObserverInterface
{

    protected $addressRepository;

    public function __construct(
        \Magento\Customer\Api\AddressRepositoryInterface $addressRepository
    ) {

        $this->addressRepository = $addressRepository;
    }

    public function execute(Observer $observer)
    {

        $order = $observer->getEvent()->getOrder();
        $quote = $observer->getEvent()->getQuote();

        // Quote get shipping address

        $quoteShippingAddress = $quote->getShippingAddress();
        $orderShippingAddress = $order->getShippingAddress();

        if ($orderShippingAddress) {
            $orderShippingAddress->setData(
                "service_level_code",
                $quoteShippingAddress->getData("price_skydropx_level")
            );
            $orderShippingAddress->setData(
                "service_level_name",
                $quoteShippingAddress->getData("price_skydropx_level")
            );
        }


        if ($quoteShippingAddress->getCustomerAddressId() != '' && is_numeric($quoteShippingAddress->getCustomerAddressId())) {

            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $customerAddress = $objectManager->create("Magento\Customer\Model\Address")->load($quoteShippingAddress->getCustomerAddressId());
            $customerAddress->setData("service_level_code", $quoteShippingAddress->getData("price_skydropx_level"));
            $customerAddress->setData("service_level_name", $quoteShippingAddress->getData("price_skydropx_level"))->save();
        }
    }
}
